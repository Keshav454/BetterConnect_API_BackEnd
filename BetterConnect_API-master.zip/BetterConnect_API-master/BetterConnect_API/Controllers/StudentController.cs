﻿using BetterConnect_API.Entities;
using BetterConnect_API.Interfaces;
using BetterConnect_API.Models;
using Microsoft.AspNetCore.Mvc;

namespace BetterConnect_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly IStudentService _studentService;
        public StudentController(IStudentService studentService)
        {
            _studentService = studentService;
        }

        [Route("StudentRegistration")]
        [HttpPost]
        public JsonResult SaveStudentDetails(SaveStudentRequest saveStudentRequest)
        {
            return _studentService.SaveStudentDetails(saveStudentRequest);
        }

        [Route("GetStudentDetailsByTeacherId")]
        [HttpPost]
        public List<Student> GetStudentDetailsByTeacherId(int teacherId)
        {
            return _studentService.GetStudentDetailsByTeacherId(teacherId);
        }
    }
}
