﻿using BetterConnect_API.Entities;
using BetterConnect_API.Interfaces;
using BetterConnect_API.Models;
using Microsoft.AspNetCore.Mvc;

namespace BetterConnect_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeacherController : ControllerBase
    {
        private readonly ITeacherService _teacherService;

        public TeacherController(ITeacherService teacherService)
        {
            _teacherService = teacherService;
        }

        [Route("GetTeacherDetails")]
        [HttpPost]
        public List<TeacherDetails> GetTeacherDetails([FromBody] SearchTeachersRequest searchTeacherDetails)
        {
            return _teacherService.GetTeacherDetails(searchTeacherDetails);
        }

        [Route("TeacherRegistration")]
        [HttpPost]
        public JsonResult TeacherRegistration([FromBody] TeacherRegistrationRequest teacherRegistrationRequest)
        {
            return _teacherService.TeacherRegistration(teacherRegistrationRequest);
        }

        [Route("IsEmailOrPhoneAlreadyExist")]
        [HttpPost]
        public JsonResult IsEmailOrPhoneAlreadyExist(string email, string phone)
        {
            var  result = _teacherService.IsEmailOrPhoneAlreadyExist(email, phone);
            return new JsonResult(new { result = result.Item1, message = result.Item2 });
        }

        [Route("SendEmail")]
        [HttpPost]
        public void SendEmail(string to, string subject, string body)
        {
            _teacherService.SendEmail(to, subject, body);
        }

        //[Route("UpdateTeacherDetails")]
        //[HttpPost]
        //public JsonResult UpdateTeacherDetails(Teacher teacher)
        //{
        //    return null;
        //}
    }
}
