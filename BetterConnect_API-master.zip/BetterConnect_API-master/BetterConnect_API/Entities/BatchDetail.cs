﻿using System;
using System.Collections.Generic;

namespace BetterConnect_API.Entities;

public partial class BatchDetail
{
    public int BatchId { get; set; }

    public string Class { get; set; } = null!;

    public string Subject { get; set; } = null!;

    public string Board { get; set; } = null!;

    public string Mode { get; set; } = null!;

    public int Fees { get; set; }

    public string Time { get; set; } = null!;

    public int TeacherId { get; set; }

    public string BatchStrength { get; set; } = null!;

    public string? Feature { get; set; }

    public virtual Teacher? Teacher { get; set; } 
}
