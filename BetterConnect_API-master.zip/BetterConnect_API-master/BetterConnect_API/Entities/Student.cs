﻿using System;
using System.Collections.Generic;

namespace BetterConnect_API.Entities;

public partial class Student
{
    public int StudentId { get; set; }

    public string Name { get; set; } = null!;

    public string Phone { get; set; } = null!;

    public string? Address { get; set; }

    public string? State { get; set; }

    public string City { get; set; } = null!;

    public int? Pincode { get; set; }

    public int TeacherId { get; set; }

    public int BatchId { get; set; }

    public int UserId { get; set; }

    public DateTime CurrentDateTime { get; set; }
}
