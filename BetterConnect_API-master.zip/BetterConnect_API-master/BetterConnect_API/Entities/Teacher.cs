﻿using System;
using System.Collections.Generic;

namespace BetterConnect_API.Entities;

public partial class Teacher
{
    public int TeacherId { get; set; }

    public string Name { get; set; } = null!;

    public string? Gender { get; set; }

    public string Address { get; set; } = null!;

    public string City { get; set; } = null!;

    public string? State { get; set; }

    public int Pincode { get; set; }

    public string Phone { get; set; } = null!;

    public string Qualification { get; set; } = null!;

    public int Experience { get; set; }

    public string CurrentlyAssociated { get; set; } = null!;

    public int? UserId { get; set; }

    public byte[]? Document { get; set; }

    public byte[]? Image { get; set; }

    public string? Bio { get; set; }

    public virtual ICollection<BatchDetail> BatchDetails { get; set;} //= new List<BatchDetail>();
}
