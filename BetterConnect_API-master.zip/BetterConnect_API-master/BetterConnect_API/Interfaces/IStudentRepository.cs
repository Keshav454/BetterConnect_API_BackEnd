﻿using BetterConnect_API.Entities;

namespace BetterConnect_API.Interfaces
{
    public interface IStudentRepository
    {
        bool SaveStudentDetails(Student student);
        List<Student> GetStudentDetailsByTeacherId(int teacherId);
    }
}
