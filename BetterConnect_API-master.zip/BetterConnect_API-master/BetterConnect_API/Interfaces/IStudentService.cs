﻿using BetterConnect_API.Entities;
using BetterConnect_API.Models;
using Microsoft.AspNetCore.Mvc;

namespace BetterConnect_API.Interfaces
{
    public interface IStudentService
    {
        JsonResult SaveStudentDetails(SaveStudentRequest saveStudentRequest);
        List<Student> GetStudentDetailsByTeacherId(int teacherId);
    }
}
