﻿using BetterConnect_API.Entities;
using BetterConnect_API.Models;
using Microsoft.AspNetCore.Mvc;

namespace BetterConnect_API.Interfaces
{
    public interface ITeacherRepository
    {
        bool IsPhoneAlreadyExist(string phone);
        List<TeacherDetails> GetTeacherDeatialsByLocation(SearchTeachersRequest search);
        Teacher GetTeacherByTeacherId(int teacherId);
        bool SaveTeacherBatchDetails(Teacher teacher);
        bool UpdateTeacherDetails(Teacher teacher);
    }
}
