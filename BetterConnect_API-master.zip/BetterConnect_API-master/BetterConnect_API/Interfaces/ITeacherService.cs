﻿using BetterConnect_API.Entities;
using BetterConnect_API.Models;
using Microsoft.AspNetCore.Mvc;

namespace BetterConnect_API.Interfaces
{
    public interface ITeacherService
    {
        List<TeacherDetails> GetTeacherDetails(SearchTeachersRequest searchTeachers);
        JsonResult TeacherRegistration(TeacherRegistrationRequest teacher);
        Tuple<bool, string> IsEmailOrPhoneAlreadyExist(string email, string phone);
        bool SendEmail(string to, string subject, string body);
    }
}
