﻿using BetterConnect_API.Entities;

namespace BetterConnect_API.Interfaces
{
    public interface IUserRepository
    {
        int SaveUserDetail(User user);
        bool UpdateUserRoleAndIsActiveFlag(int userId, bool isActive, string role);
        bool IsEmailAlreadyExist(string email);
        bool SendEmail(string to, string subject, string body);
    }
}
