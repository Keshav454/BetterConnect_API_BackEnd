﻿using BetterConnect_API.Entities;

namespace BetterConnect_API.Models
{
    public class SaveStudentRequest
    {
       public User User { get; set; }
        public  Student Student { get; set; }
    }
}
