﻿namespace BetterConnect_API.Models
{
    public class SearchTeachersRequest
    {
        public string Location { get; set; }
        public string Subject { get; set; }
        public string Class { get; set; }
        public string Mode { get; set; }
        public int PageSize { get; set; } = 10;
        public int PageNumber { get; set; } = 1;
    }
}
