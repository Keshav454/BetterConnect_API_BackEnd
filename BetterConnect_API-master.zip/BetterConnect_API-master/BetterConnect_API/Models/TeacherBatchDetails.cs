﻿using BetterConnect_API.Entities;

namespace BetterConnect_API.Models
{
    public class TeacherBatchDetails
    {
        public Teacher Teacher { get; set; } 
        public List<BatchDetail> BatchDetails { get; set; }
    }
}
