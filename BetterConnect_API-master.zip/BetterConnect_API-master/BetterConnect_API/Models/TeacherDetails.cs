﻿namespace BetterConnect_API.Models
{
    public class TeacherDetails
    {
        public int TeacherId { get; set; }
        public string Name { get; set; }
        public string? Gender { get; set; }
        public string Address { get; set; }
        public string? State { get; set; }
        public string City { get; set; }
        public int Pincode { get; set; }
        public string? Email { get; set; }
        public string Phone { get; set; }
        public string Qualification { get; set; }
        public int Experience { get; set; }
        public string CurrentlyAssociated { get; set; }
        public string Distance { get; set; } = "0";
        public int BatchId { get; set; }
        public string Class { get; set; }
        public string Subject { get; set; }
        public string Board { get; set; }
        public string Mode { get; set; }
        public int Fees { get; set; }
        public string Time { get; set; }
        public string BatchStrength { get; set; }
        public string? Feature { get; set; }
    }
}
