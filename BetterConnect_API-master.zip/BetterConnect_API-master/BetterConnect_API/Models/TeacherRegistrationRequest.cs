﻿using BetterConnect_API.Entities;

namespace BetterConnect_API.Models
{
    public class TeacherRegistrationRequest
    {
        public User User { get; set; }
        public Teacher Teacher { get; set; }
    }
}
