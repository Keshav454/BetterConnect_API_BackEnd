﻿using BetterConnect_API.Entities;
using BetterConnect_API.Interfaces;

namespace BetterConnect_API.Repositories
{
    public class StudentRepository : IStudentRepository
    {
        private readonly BetterConnectContext _betterConnectContext;
        private readonly ILogger _logger;
        public StudentRepository(BetterConnectContext betterConnectContext)
        {
            _betterConnectContext = betterConnectContext;
            //_logger = logger;
        }

        public List<Student> GetStudentDetailsByTeacherId(int teacherId)
        {
            return _betterConnectContext.Students.Where(x => x.TeacherId == teacherId).ToList();
        }

        public bool SaveStudentDetails(Student student)
        {
            try
            {
                _betterConnectContext.Students.Add(student);
                _betterConnectContext.SaveChanges();
            }
            catch (Exception ex)
            {
                _logger.Log(LogLevel.Error, ex.ToString());
                return false;
            }
            return true;
        }


    }
}
