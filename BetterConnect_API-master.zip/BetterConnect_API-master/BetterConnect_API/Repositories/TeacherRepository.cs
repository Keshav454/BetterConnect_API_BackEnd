﻿using BetterConnect_API.Entities;
using BetterConnect_API.Interfaces;
using BetterConnect_API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace BetterConnect_API.Repositories
{
    public class TeacherRepository : ITeacherRepository
    {
        private readonly BetterConnectContext _betterConnectContext;
        private readonly ILogger _logger;
        public TeacherRepository(ILogger<TeacherRepository> logger, BetterConnectContext betterConnectContext)
        {
            _betterConnectContext = betterConnectContext;
            _logger = logger;
        }

        public bool IsPhoneAlreadyExist(string phone)
        {
            try
            {
                return _betterConnectContext.Teachers.Where(x => x.Phone.ToLower() == phone.ToLower()).ToList().Count > 0;
            }
            catch (Exception ex)
            {
                _logger.Log(LogLevel.Error, "Error in IsPhoneAlreadyExist: " + ex.ToString());
            }
            return false;
        }

        public List<TeacherDetails> GetTeacherDeatialsByLocation(SearchTeachersRequest search)
        {
            List<TeacherDetails> teacherDetails = new List<TeacherDetails>();
            try
            {
                using (SqlConnection conn = new SqlConnection(_betterConnectContext.Database.GetDbConnection().ConnectionString))
                {
                    var city = search?.Location?.Split(",").Last() ?? string.Empty;
                    conn.Open();
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = conn;
                        command.CommandText = "GetTeacherDetails";
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@Location", city ?? string.Empty);
                        command.Parameters.AddWithValue("@Class", search.Class ?? string.Empty);
                        command.Parameters.AddWithValue("@Subject", search.Subject ?? string.Empty);
                        command.Parameters.AddWithValue("@Mode", search.Mode ?? string.Empty);

                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                teacherDetails.Add(new TeacherDetails()
                                {
                                    TeacherId = reader.GetInt32("TeacherId"),
                                    Name = reader.GetString("Name"),
                                    //Gender = reader.GetString("Gender"),
                                    Address = reader.GetString("Address"),
                                    //State = reader.GetString("State"),
                                    City = reader.GetString("City"),
                                    Pincode = reader.GetInt32("Pincode"),
                                    //Email = reader.GetString("Email"),
                                    Phone = reader.GetString("Phone"),
                                    Qualification = reader.GetString("Qualification"),
                                    Experience = reader.GetInt32("Experience"),
                                    CurrentlyAssociated = reader.GetString("CurrentlyAssociated"),
                                    BatchId = reader.GetInt32("BatchId"),
                                    Class = reader.GetString("Class"),
                                    Subject = reader.GetString("Subject"),
                                    Board = reader.GetString("Board"),
                                    Mode = reader.GetString("Mode"),
                                    Fees = reader.GetInt32("Fees"),
                                    Time = reader.GetString("Time"),
                                    BatchStrength = reader.GetString("BatchStrength"),
                                    //Feature = reader.GetString("Feature")
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Log(LogLevel.Error, "Error in GetTeacherDeatialsByLocation: "+ ex.ToString());
            }
            return teacherDetails;
        }

        public Teacher GetTeacherByTeacherId(int teacherId)
        {
            Teacher teacher = new Teacher();
            try
            {
                teacher = _betterConnectContext.Teachers.Where(x => x.TeacherId == teacherId).FirstOrDefault();

            }
            catch (Exception ex)
            {
                _logger.Log(LogLevel.Error, "Error in GetTeacherByTeacherId: "+ ex.ToString());
            }
            return teacher;
        }

        public bool UpdateTeacherDetails(Teacher teacher)
        {
            try
            {
                _betterConnectContext.Teachers.Update(teacher);
                _betterConnectContext.SaveChanges();
            }
            catch (Exception ex)
            {
                _logger.Log(LogLevel.Error, "Error in UpdateTeacherDetails with TeacherId: " + teacher.TeacherId);
                return false;
            }
            return true;
        }

        public bool SaveTeacherBatchDetails(Teacher teacher)
        {
            try
            {
                _betterConnectContext.Teachers.Add(teacher);
                _betterConnectContext.SaveChanges();
            }
            catch (Exception ex)
            {
                //_logger.Log(LogLevel.Error, ex.ToString());
                return false;
            }
            return true;
        }
    }
}
