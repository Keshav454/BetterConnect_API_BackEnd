﻿using BetterConnect_API.Entities;
using BetterConnect_API.Interfaces;
using System.Net.Mail;
using System.Net;

namespace BetterConnect_API.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly IConfiguration _config;
        private readonly BetterConnectContext _betterConnectContext;
        private readonly ILogger _logger;

        public UserRepository(IConfiguration config, BetterConnectContext betterConnectContext, ILogger<UserRepository> logger)
        {
            _config = config;
            _betterConnectContext = betterConnectContext;
            _logger = logger;
        }

        public void GetUserDetails(string email, string password)
        {
            _betterConnectContext.Users.Where(x => x.Email == email && x.Password == password).FirstOrDefault();
        }

        public int SaveUserDetail(User user)
        {
            try
            {
                _betterConnectContext.Users.Add(user);
                _betterConnectContext.SaveChanges();
            }
            catch (Exception ex)
            {
                _logger.Log(LogLevel.Error, "Error in SaveUserDetail: " + ex.ToString());
                return 0;
            }
            return user.UserId;
        }

        public bool UpdateUserRoleAndIsActiveFlag(int userId, bool isActive, string role = null)
        {
            try
            {
                User user = _betterConnectContext.Users.Where(x => x.UserId == userId).FirstOrDefault();
                user.IsActive = isActive;
                
                if (role != null)
                    user.Role = role;
                
                _betterConnectContext.Users.Update(user);
                _betterConnectContext.SaveChanges();
            }
            catch (Exception ex)
            {
                _logger.Log(LogLevel.Error, "Error in UpdateUserRoleAndIsActiveFlag: "+ ex.ToString());
                return false;
            }
            return true;
        }

        public bool IsEmailAlreadyExist(string email)
        {
            try
            {
                return _betterConnectContext.Users.Where(x => x.Email.ToLower() == email.ToLower()).ToList().Count > 0;
            }
            catch (Exception ex)
            {
                _logger.Log(LogLevel.Error, "Error in IsEmailAlreadyExist: "+ ex.ToString());
                return false;
            }
        }

        public bool SendEmail(string to, string subject, string body)
        {
            try
            {
                if (Convert.ToBoolean(_config["EnableEmailSend"]))
                {
                    string from = _config["SMTP:From"];
                    string endPoint = _config["SMTP:EndPoint"];
                    int port = Convert.ToInt32(_config["SMTP:Port"]);
                    string userName = _config["SMTP:UserName"];
                    string credentials = _config["SMTP:Credentials"];

                    var client = new SmtpClient(endPoint, port)
                    {
                        Credentials = new NetworkCredential(userName, credentials),
                        EnableSsl = true
                    };

                    client.Send(from, to, subject, body);
                    _logger.Log(LogLevel.Information, "Email Send Successfully to User: " + to);
                }
            }
            catch (Exception ex)
            {
                _logger.Log(LogLevel.Error, "Error while Sending Email: " + ex.ToString());
                return false;
            }
            return true;
        }
    }
}
