﻿using BetterConnect_API.Entities;
using BetterConnect_API.Interfaces;
using BetterConnect_API.Models;
using Microsoft.AspNetCore.Mvc;

namespace BetterConnect_API.Services
{
    public class StudentService : IStudentService
    {
        private readonly IStudentRepository _studentRepository;
        private readonly IUserRepository _userRepository;
        private readonly ILogger _logger;

        public StudentService(ILogger<StudentService> logger, IStudentRepository studentRepository, IUserRepository userRepository)
        {
            _studentRepository = studentRepository;
            _userRepository = userRepository;
            _logger = logger;
        }

        public List<Student> GetStudentDetailsByTeacherId(int teacherId)
        {
            return _studentRepository.GetStudentDetailsByTeacherId(teacherId);
        }

        public JsonResult SaveStudentDetails(SaveStudentRequest request)
        {
            if (request != null && request.User != null && request.Student != null)
            {
                int userId = _userRepository.SaveUserDetail(request.User);
                _logger.Log(LogLevel.Information, "User Saved with UserId: " + userId + ", Role: " + request.User.Role);
                if (userId > 0)
                {
                    request.Student.UserId = userId;
                    if (_studentRepository.SaveStudentDetails(request.Student))
                    {
                        _logger.Log(LogLevel.Information, "Student Details Saved In DB: " + request.Student.StudentId);
                        
                        if (_userRepository.SendEmail(request.User.Email, "",""))
                        {
                            _logger.Log(LogLevel.Information, "Successfully Saved Student Details: " + request.Student.StudentId);
                            return new JsonResult(new { result = true, message = "Successfully Saved Student Details." });
                        }
                    }
                }
            }
            return new JsonResult(new { result = false, message = "Fail to Save Student Details." });
        }
    }
}
