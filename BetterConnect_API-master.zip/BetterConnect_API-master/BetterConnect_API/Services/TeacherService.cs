﻿using BetterConnect_API.Interfaces;
using BetterConnect_API.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;

namespace BetterConnect_API.Services
{
    public class TeacherService : ITeacherService
    {
        private ITeacherRepository _teacherRepository;
        private readonly ILogger _logger;
        private readonly IUserRepository _userRepository;

        public TeacherService(ILogger<TeacherService> logger, ITeacherRepository teacherRepository, IUserRepository userRepository)
        {
            _teacherRepository = teacherRepository;
            _logger = logger;
            _userRepository = userRepository;
        }

        public List<TeacherDetails> GetTeacherDetails(SearchTeachersRequest searchTeachers)
        {
            List<TeacherDetails> teacherDetails = new List<TeacherDetails>();

            if (searchTeachers != null && !string.IsNullOrEmpty(searchTeachers.Location))
            {
                teacherDetails = _teacherRepository.GetTeacherDeatialsByLocation(searchTeachers);
            }

            if (teacherDetails != null && teacherDetails.Count > 0)
            {
                foreach (var teacherDetail in teacherDetails)
                {
                    teacherDetail.Distance = CalculateDistance(searchTeachers.Location, string.Join(", ", teacherDetail.Address, teacherDetail.City)).Result;
                }
            }
            return teacherDetails;
        }

        public Tuple<bool, string> IsEmailOrPhoneAlreadyExist(string email, string phone)
        {
            if (!string.IsNullOrEmpty(email) && _userRepository.IsEmailAlreadyExist(email))
            {
                return new Tuple<bool, string>(true, "Email already exist.");
            }
            else if (!string.IsNullOrEmpty(phone) && _teacherRepository.IsPhoneAlreadyExist(phone))
            {
                return new Tuple<bool, string>(true, "Contact Number already exist.");
            }
            return new Tuple<bool, string>(false, string.Empty);
        }

        public JsonResult TeacherRegistration(TeacherRegistrationRequest request)
        {
            if (request != null && request.User != null && request.Teacher != null)
            {
                var isEmailOrPhoneAlreadyExist = IsEmailOrPhoneAlreadyExist(request.User.Email, request.Teacher.Phone);
                if (isEmailOrPhoneAlreadyExist.Item1)
                {
                    _logger.Log(LogLevel.Information, isEmailOrPhoneAlreadyExist.Item2);
                    return new JsonResult(new { result = true, message = isEmailOrPhoneAlreadyExist.Item2 });
                }

                int userId = _userRepository.SaveUserDetail(request.User);
                _logger.Log(LogLevel.Information, "User Saved with UserId: " + userId + ", Role: " + request.User.Role);
                
                if (userId > 0)
                {
                    request.Teacher.UserId = userId;
                    if (_teacherRepository.SaveTeacherBatchDetails(request.Teacher))
                    {
                        _logger.Log(LogLevel.Information, "Teacher Details Saved In DB: " + request.Teacher.TeacherId);
                        if (_userRepository.SendEmail(request.User.Email, "",""))
                        {
                            _logger.Log(LogLevel.Information, "Teacher Registration Done Successfully. " + request.Teacher.TeacherId);
                            return new JsonResult(new { result = true, message = "Registration Done Successfully." });
                        }
                    }
                }

            }
            return new JsonResult(new { result = false, message = "Registration Failed." });
        }

        private async Task<string> CalculateDistance(string origin, string destination)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    string url = "https://maps.googleapis.com/maps/api/distancematrix/json?origins={0}&destinations={1}&key=AIzaSyDR4DGJXgDJSOStVkNzHxnJbmTEJnzst_o";
                    var response = await client.GetAsync(string.Format(url, origin, destination));
                    string result = await response.Content.ReadAsStringAsync();
                    JObject jsonRes = JObject.Parse(result);

                    if (jsonRes.Root["status"].ToString() == "OK")
                    {
                        return JObject.Parse(result).Root["rows"][0]["elements"][0]["distance"]["text"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in Distance Calculating: "+ ex.ToString());
            }
            return "0";
        }

        public bool SendEmail(string to, string subject, string body)
        {
            return _userRepository.SendEmail(to, subject, body);
        }
    }
}
